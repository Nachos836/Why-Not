﻿namespace Drift
{
    public class BridgeService : IBridgeService
    {
        public VehicleInfo Vehicle { get; } = new VehicleInfo();
    }
}
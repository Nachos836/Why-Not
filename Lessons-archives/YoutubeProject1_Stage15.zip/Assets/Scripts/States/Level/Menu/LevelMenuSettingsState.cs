﻿using Drift.Ui;
using UnityEngine.InputSystem;

namespace Drift.States
{
    public class LevelMenuSettingsState : IState
    {
        private readonly IInputService inputService;
        
        public readonly ICommand Back;
        
        public IObservableValue<bool> IsEnabled = new ObservableValue<bool>(false);
        
        public LevelMenuSettingsState(IStateMachine<LevelMenuTrigger> stateMachine,
            IInputService inputService)
        {
            this.inputService = inputService;
            Back = new DelegateCommand(() => stateMachine.Fire(LevelMenuTrigger.Main));
        }
        
        public void OnEnter()
        {
            IsEnabled.Value = true;
            inputService.UI.ToggleMenu.performed += OnToggleMenuPerformed;
        }

        private void OnToggleMenuPerformed(InputAction.CallbackContext obj)
        {
            Back.TryExecute();
        }

        public void OnExit()
        {
            IsEnabled.Value = false;
            inputService.UI.ToggleMenu.performed -= OnToggleMenuPerformed;
        }
    }
}
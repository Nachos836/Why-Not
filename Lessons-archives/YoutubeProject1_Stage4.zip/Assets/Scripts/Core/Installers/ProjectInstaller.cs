﻿using UnityEngine;
using Zenject;

namespace Drift
{
    public class ProjectInstaller : MonoInstaller
    {
        [SerializeField]
        private Database database;
        
        public override void InstallBindings()
        {
            Container.BindInterfacesTo<InputService>()
                .AsSingle()
                .Lazy();

            Container.BindInterfacesTo<GameService>()
                .AsSingle()
                .NonLazy();

            Container.BindInterfacesTo<Database>()
                .FromInstance(database)
                .AsSingle();
        }
    }
}
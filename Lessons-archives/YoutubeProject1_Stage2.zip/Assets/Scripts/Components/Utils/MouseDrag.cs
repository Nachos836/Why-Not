using Unity.Entities;

namespace Drift.Components
{
    [GenerateAuthoringComponent]
    public struct MouseDrag : IComponentData
    {
        public float Distance;
        public float Acceleration;
    }
}

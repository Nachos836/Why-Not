﻿using UnityEngine;
using Zenject;

namespace Drift
{
    public class LevelSceneInstaller : MonoInstaller
    {
        [SerializeField]
        private SurfaceService surfaces;
        
        public override void InstallBindings()
        {
            Container.BindInterfacesAndSelfTo<SurfaceService>()
                .FromInstance(surfaces)
                .AsSingle();
        }
    }
}
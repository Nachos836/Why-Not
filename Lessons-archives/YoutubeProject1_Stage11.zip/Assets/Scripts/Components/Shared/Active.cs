﻿using Unity.Entities;

namespace Drift
{
    public struct Active : IComponentData
    {
        
    }
}
﻿using Unity.Entities;

namespace Drift
{
    [GenerateAuthoringComponent]
    public struct VehicleDebug : IComponentData
    {
        
    }
}
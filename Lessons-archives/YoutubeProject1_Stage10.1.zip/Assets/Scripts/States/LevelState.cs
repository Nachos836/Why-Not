﻿using Drift.Ui;
using Unity.Assertions;
using UnityEngine;

namespace Drift.States
{
    public class LevelState : IState
    {
        private LevelMenuView view;
        private IGameService gameService;

        public LevelState(IGameService gameService)
        {
            this.gameService = gameService;
        }

        public void OnEnter()
        {
            view = Object.FindObjectOfType<LevelMenuView>();
            Assert.IsNotNull(view, "Main menu view not found");
            view.MainMenu += OnMainMenu;
        }

        private void OnMainMenu()
        {
            gameService.Fire(GameTrigger.MainMenu);
        }

        public void OnExit()
        {
            view.MainMenu -= OnMainMenu;
        }
    }
}
﻿using Unity.Entities;

namespace Drift
{
    public struct StateChanged : IComponentData
    {
        
    }
}
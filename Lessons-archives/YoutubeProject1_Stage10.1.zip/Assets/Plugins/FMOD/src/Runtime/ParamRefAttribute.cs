﻿using UnityEngine;

namespace FMODUnity
{
    public class ParamRefAttribute : PropertyAttribute
    {
    }
}

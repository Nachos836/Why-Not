﻿using Unity.Entities;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Physics.Authoring;
using UnityEngine;
using Collider = Unity.Physics.Collider;

namespace Drift.Components
{
    public class WheelAuthoring : MonoBehaviour, IConvertGameObjectToEntity
    {
        [Header("Collider")]
        public float Radius;
        public float Width;
        public PhysicsCategoryTags BelongsTo;
        public PhysicsCategoryTags CollidesWith;
        
        [Header("Suspension")]
        public float SuspensionLength;
        
        public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
        {
            dstManager.AddComponents(entity, new ComponentTypes(
                typeof(Wheel),
                typeof(WheelOrigin),
                typeof(WheelInput),
                typeof(WheelContact)
                ));
            
            var wheelCollider = CylinderCollider.Create(new CylinderGeometry
            {
                Center = float3.zero,
                Height = Width,
                Radius = Radius,
                BevelRadius = 0.01f,
                SideCount = 12,
                Orientation = quaternion.AxisAngle(math.up(), math.PI * 0.5f)
            }, new CollisionFilter
            {
                BelongsTo = BelongsTo.Value,
                CollidesWith = CollidesWith.Value
            });

            conversionSystem.BlobAssetStore.AddUniqueBlobAsset(ref wheelCollider);
            
            dstManager.SetComponentData(entity, new Wheel
            {
                Radius = Radius,
                Width = Width,
                SuspensionLength = SuspensionLength,
                Collider = wheelCollider
            });
            dstManager.SetComponentData(entity, new WheelOrigin
            {
                Value = new RigidTransform(transform.localRotation, transform.localPosition)
            });
        }
    }

    public struct Wheel : IComponentData
    {
        public float Radius;
        public float Width;
        public float SuspensionLength;
        public BlobAssetReference<Collider> Collider;
    }

    public struct WheelOrigin : IComponentData
    {
        public RigidTransform Value;
    }

    public struct WheelInput : IComponentData
    {
        public float3 Up;
        public RigidTransform WorldTransform;
    }

    public struct WheelContact : IComponentData
    {
        public bool IsInContact;
        public float3 Point;
        public float3 Normal;
        public float Distance;
    }
}
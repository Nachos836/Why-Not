﻿using Unity.Entities;

namespace Drift.Tweening
{
    
    [UpdateInGroup(typeof(SimulationSystemGroup))]
    public class TweenSystemGroup : ComponentSystemGroup
    {
    }
}
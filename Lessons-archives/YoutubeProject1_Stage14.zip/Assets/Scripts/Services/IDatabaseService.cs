﻿namespace Drift
{
    public interface IDatabaseService
    {
        LevelDefinition[] Levels { get; }
    }
}
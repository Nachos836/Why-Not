﻿using System;
using Unity.Assertions;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Drift.Ui
{
    public class LevelMenuView : MonoBehaviour
    {
        public event UnityAction MainMenu
        {
            add
            {
                Assert.IsNotNull(mainMenuButton, "Main menu button not defined");
                mainMenuButton.onClick.AddListener(value);
            }
            remove
            {
                Assert.IsNotNull(mainMenuButton, "Main menu button not defined");
                mainMenuButton.onClick.RemoveListener(value);
            }
        }
        
        [SerializeField]
        private Button mainMenuButton;
    }
}
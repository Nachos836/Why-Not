﻿using UnityEngine;

namespace Drift
{
    [CreateAssetMenu(menuName = "Database/Surface")]
    public class SurfaceDefinition : ScriptableObject
    {
        public int RuntimeIndex;
        public GameObject Skidmarks;
    }
}
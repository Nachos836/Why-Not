﻿using Unity.Entities;

namespace Drift
{
    public static class EntityExtensions
    {
        public static void Link(this EntityManager entityManager, Entity ownerEntity, Entity entity)
        {
            var buffer = entityManager.AddBuffer<LinkedEntityGroup>(ownerEntity);
            buffer.Add(entity);
        }
    }
}
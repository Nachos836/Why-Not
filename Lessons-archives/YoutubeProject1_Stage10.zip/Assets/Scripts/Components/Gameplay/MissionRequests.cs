﻿using Unity.Entities;

namespace Drift
{
    public struct ActiveMissionRequest : IComponentData
    {
        public Entity Entity;

        public ActiveMissionRequest(Entity entity)
        {
            Entity = entity;
        }
    }
    
    public struct CompleteMissionRequest : IComponentData
    {
        public Entity Entity;

        public CompleteMissionRequest(Entity entity)
        {
            Entity = entity;
        }
    }
    
    public struct CancelMissionRequest : IComponentData
    {
        public Entity Entity;

        public CancelMissionRequest(Entity entity)
        {
            Entity = entity;
        }
    }
}
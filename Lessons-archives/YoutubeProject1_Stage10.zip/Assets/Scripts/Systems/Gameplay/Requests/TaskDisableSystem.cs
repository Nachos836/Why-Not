﻿using Unity.Collections;
using Unity.Entities;
using UnityEngine;

namespace Drift
{
    [UpdateInGroup(typeof(EventsSystemGroup))]
    public class TaskDisableSystem : SystemBase
    {
        private EntityQuery requests;
        
        protected override void OnUpdate()
        {
            Entities
                .WithStoreEntityQueryInField(ref requests)
                .ForEach((in DisableTaskRequest disableTaskRequest) =>
                {
                    DisableTask(EntityManager, disableTaskRequest.Entity);
                }).WithStructuralChanges().Run();
            EntityManager.DestroyEntity(requests);
        }

        public static void DisableTask(EntityManager entityManager, Entity taskEntity)
        {
            Debug.Log("Task disabled: " + entityManager.GetName(taskEntity));
            
            entityManager.SetEnabled(taskEntity, false);
            entityManager.RemoveComponent<Completed>(taskEntity);
            entityManager.AddComponent<StateChanged>(taskEntity);
            
            if (entityManager.HasComponent<TaskGroup>(taskEntity))
            {
                var children = entityManager.GetBuffer<ChildLink>(taskEntity);

                if (!children.IsEmpty)
                {
                    using var childrenCopy = children.ToNativeArray(Allocator.Temp);
                    foreach (var child in childrenCopy)
                    {
                        DisableTask(entityManager, child.Entity);
                    }
                }
            }
        }

    }
}
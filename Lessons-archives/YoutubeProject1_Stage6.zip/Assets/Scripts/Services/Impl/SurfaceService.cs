﻿using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;

namespace Drift
{
    [CreateAssetMenu(menuName = "Database/Surfaces")]
    public class SurfaceService : ScriptableObject, ISurfaceService, IPrefabProvider
    {
        [SerializeField]
        private SurfaceDefinition[] surfaces;
        
        public SurfaceDefinition[] Surfaces => surfaces;
        
        private SurfaceData[] surfaceData;
        
        private struct SurfaceData
        {
            public Entity SkidmarksPrefab;
            public Entity SurfaceSoundPrefab;
        }
        
        public void DeclarePrefabs(List<GameObject> referencedPrefabs)
        {
            for (var index = 0; index < surfaces.Length; index++)
            {
                var surfaceDefinition = surfaces[index];
                surfaceDefinition.RuntimeIndex = index;
                if (surfaceDefinition.Skidmarks != null) referencedPrefabs.Add(surfaceDefinition.Skidmarks);
                if (surfaceDefinition.SurfaceSound != null) referencedPrefabs.Add(surfaceDefinition.SurfaceSound);
            }
        }
        
        public void PreparePrefabs(GameObjectConversionSystem conversionSystem)
        {
            surfaceData = new SurfaceData[surfaces.Length];
            for (var index = 0; index < surfaces.Length; index++)
            {
                var surfaceDefinition = surfaces[index];
                if (surfaceDefinition.Skidmarks != null)
                {
                    surfaceData[surfaceDefinition.RuntimeIndex].SkidmarksPrefab =
                        conversionSystem.GetPrimaryEntity(surfaceDefinition.Skidmarks);
                }
                else
                {
                    surfaceData[surfaceDefinition.RuntimeIndex].SkidmarksPrefab = Entity.Null;
                }
                if (surfaceDefinition.SurfaceSound != null)
                {
                    surfaceData[surfaceDefinition.RuntimeIndex].SurfaceSoundPrefab =
                        conversionSystem.GetPrimaryEntity(surfaceDefinition.SurfaceSound);
                }
                else
                {
                    surfaceData[surfaceDefinition.RuntimeIndex].SurfaceSoundPrefab = Entity.Null;
                }
            }
        }
        
        public Entity GetSkidmarksPrefab(int surfaceIndex)
        {
            return surfaceData[surfaceIndex].SkidmarksPrefab;
        }
        
        public Entity GetSurfaceSoundPrefab(int surfaceIndex)
        {
            return surfaceData[surfaceIndex].SurfaceSoundPrefab;
        }
    }
}
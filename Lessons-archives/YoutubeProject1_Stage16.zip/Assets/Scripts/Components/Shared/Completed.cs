﻿using Unity.Entities;

namespace Drift
{
    public struct Completed : IComponentData
    {
        
    }
}
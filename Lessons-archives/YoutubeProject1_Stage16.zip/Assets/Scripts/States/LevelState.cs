﻿namespace Drift.States
{
    public class LevelState : IState
    {
        public void OnEnter()
        {
        }

        public void OnExit()
        {
        }
    }
}
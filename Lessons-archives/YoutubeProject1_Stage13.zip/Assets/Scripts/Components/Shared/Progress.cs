﻿using Unity.Entities;

namespace Drift
{
    public struct Progress : IComponentData
    {
        public float Value;
    }
}
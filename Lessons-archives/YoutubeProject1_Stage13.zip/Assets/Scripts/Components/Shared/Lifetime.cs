﻿using Unity.Entities;

namespace Drift
{
    public struct Lifetime : IComponentData
    {
        public float Time;
    }
}









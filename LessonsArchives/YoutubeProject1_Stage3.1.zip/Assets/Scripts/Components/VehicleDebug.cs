﻿using Unity.Entities;

namespace Drift.Components
{
    [GenerateAuthoringComponent]
    public struct VehicleDebug : IComponentData
    {
        
    }
}
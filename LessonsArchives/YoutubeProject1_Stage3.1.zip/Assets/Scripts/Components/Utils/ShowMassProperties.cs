﻿using Unity.Entities;

namespace Drift.Components.Utils
{
    [GenerateAuthoringComponent]
    public struct ShowMassProperties : IComponentData
    {
        
    }
}
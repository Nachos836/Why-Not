﻿using Unity.Entities;
using UnityEngine;

namespace Drift
{
    [GenerateAuthoringComponent]
    public struct ShowMassProperties : IComponentData {
    
    }
}
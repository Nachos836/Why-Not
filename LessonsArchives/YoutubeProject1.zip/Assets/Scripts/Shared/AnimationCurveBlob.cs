﻿using Unity.Assertions;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

namespace Drift
{
    public struct AnimationCurveBlob
    {
        private BlobArray<float> sampledValues;
        private float2 timeRange;

        public static BlobAssetReference<AnimationCurveBlob> Build(AnimationCurve ac, int samples, Allocator allocator)
        {
            Assert.IsNotNull(ac);
            Assert.IsTrue(ac.keys.Length > 0);
            
            using var blobBuilder = new BlobBuilder(Allocator.Temp);
            ref var root = ref blobBuilder.ConstructRoot<AnimationCurveBlob>();
            var sampledValues = blobBuilder.Allocate(ref root.sampledValues, samples);

            var timeFrom = ac.keys[0].time;
            var timeTo = ac.keys[ac.keys.Length - 1].time;
            var timeStep = (timeTo - timeFrom) / (samples - 1);

            for (int i = 0; i < samples; i++)
            {
                sampledValues[i] = ac.Evaluate(timeFrom + (i * timeStep));
            }
            
            root.timeRange = new float2(timeFrom, timeTo);

            return blobBuilder.CreateBlobAssetReference<AnimationCurveBlob>(allocator);
        }

        public float Evaluate(float time)
        {
            var len = sampledValues.Length - 1;
            
            var clamp01 = math.clamp(time, timeRange.x, timeRange.y) / (timeRange.y - timeRange.x);
            var valueIndexF = clamp01 * len;
            var valueIndex = (int) math.floor(valueIndexF);
            if (valueIndex == len) return sampledValues[len];

            var bottom = sampledValues[valueIndex];
            var top = sampledValues[valueIndex + 1];
            return math.lerp(bottom, top, math.frac(valueIndexF));
        }
    }
}
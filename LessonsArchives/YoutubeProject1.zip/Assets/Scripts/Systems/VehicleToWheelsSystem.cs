﻿using Drift.Components;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

namespace Drift.Systems
{
    [UpdateInGroup(typeof(FixedStepSimulationSystemGroup))]
    public class VehicleToWheelsSystem : SystemBase
    {
        protected override void OnUpdate()
        {
            Entities.ForEach((in Vehicle vehicle, in Translation translation, in Rotation rotation) =>
            {
                for (int i = 0; i < vehicle.Wheels.Length; i++)
                {
                    var wheelEntity = vehicle.Wheels[i];
                    var origin = GetComponent<WheelOrigin>(wheelEntity);

                    var wheelTransform = math.mul(new RigidTransform(rotation.Value, translation.Value), origin.Value);
                    
                    var wheelInput = new WheelInput
                    {
                        WorldTransform = wheelTransform,
                        Up = math.rotate(wheelTransform.rot, math.up())
                    };
                    SetComponent(wheelEntity, wheelInput);
                }
            }).Schedule();
        }
    }
}